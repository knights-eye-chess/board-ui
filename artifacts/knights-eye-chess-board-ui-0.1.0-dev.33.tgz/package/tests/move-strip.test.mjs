import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { transform } from 'esbuild';
import { chromium } from 'playwright';

const source=readFileSync(new URL('../src/move-strip.ts',import.meta.url),'utf8');
const compiled=(await transform(source,{loader:'ts',format:'esm',target:'es2022'})).code;
const main=Array.from({length:10},(_,ply)=>({cursor:{kind:'main',ply},label:ply?`Nf${ply}`:'Starting position',number:ply?`${Math.ceil(ply/2)}${ply%2?' .':'...'}`:''}));
const branches=[{id:'short',anchor:{kind:'main',ply:3},moves:[0,1,2].map(index=>({cursor:{kind:'branch',branchId:'short',index},label:`B${index}`,iconId:index===0?'quality':''}))},{id:'long',anchor:{kind:'main',ply:5},moves:Array.from({length:9},(_,index)=>({cursor:{kind:'branch',branchId:'long',index},label:`L${index}`}))},{id:'child',parentId:'short',anchor:{kind:'branch',branchId:'short',index:1},moves:[0,1].map(index=>({cursor:{kind:'branch',branchId:'child',index},label:`C${index}`}))}];
const view={main,branches,selectedLine:main.map(item=>item.cursor),current:{kind:'main',ply:0}};
const server=createServer((req,res)=>{if(req.url==='/move-strip.js'){res.setHeader('content-type','text/javascript');res.end(compiled);}else{res.setHeader('content-type','text/html');res.end('<style>body{margin:0}#strip{width:320px}</style><div id="strip"></div>');}});

test('controlled strip resolves live center crossings, bounds selected range, and keeps navigation host-owned',async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  try{for(const width of [1280,375]){
    const page=await browser.newPage({viewport:{width,height:700},hasTouch:true}),errors=[];page.on('pageerror',error=>errors.push(error.message));await page.goto(`http://127.0.0.1:${server.address().port}`);
    await page.evaluate(async initial=>{const {mountMoveStrip}=await import('/move-strip.js');window.events=[];window.view=initial;window.strip=mountMoveStrip(document.querySelector('#strip'),{view:initial,onNavigate(cursor,details){window.events.push({cursor,source:details.source});window.view={...window.view,current:cursor};window.strip.update(window.view);},onCommand(command){window.events.push({command});},onGestureStart(){window.events.push({gesture:'start'});},onGestureEnd(){window.events.push({gesture:'end'});},onUserScroll(){window.events.push({gesture:'scroll'});},onSettled(){window.events.push({gesture:'settled'});},appearance:{resolveIcon(id){return id==='quality'?{src:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg"/%3E',width:12,height:12}:null;}}});},view);
    const root=page.locator('#strip > div');const vp=root.locator('.viewport'),buttons=root.locator('button');assert.equal(await buttons.count(),24);
    assert.equal(await root.locator('button[data-cursor="m:1"] .san').textContent(),'♞f1','default SAN display retains chess figurines');
    assert.equal(await root.locator('button.current').getAttribute('aria-current'),'true');assert.equal(await root.locator('.icon').count(),1);
    const firstMetrics=await vp.evaluate(node=>({left:node.scrollLeft,max:node.scrollWidth-node.clientWidth}));assert.equal(firstMetrics.left,0);assert.ok(firstMetrics.max>0);
    await page.evaluate(()=>{window.view={...window.view,current:{kind:'main',ply:9}};window.strip.update(window.view);document.querySelector('#strip').style.width='240px';});await page.waitForTimeout(80);
    const centerError=()=>vp.evaluate(node=>{const current=node.getRootNode().querySelector('button[aria-current="true"]').getBoundingClientRect(),outer=node.getBoundingClientRect();return Math.abs(current.left+current.width/2-outer.left-outer.width/2);});assert.ok(await centerError()<3,'resize keeps controlled current move centered before user scrolling');
    const beforeFontWidth=await root.locator('button[data-cursor="m:9"]').evaluate(button=>button.getBoundingClientRect().width);
    await page.evaluate(()=>{document.querySelector('#strip').style.setProperty('--move-font','monospace');document.querySelector('#strip').style.letterSpacing='3px';});await page.waitForTimeout(40);
    const afterFontWidth=await root.locator('button[data-cursor="m:9"]').evaluate(button=>button.getBoundingClientRect().width);assert.ok(Math.abs(afterFontWidth-beforeFontWidth)>3,'font regression changes real button metrics');assert.ok(await centerError()<3,'changed metrics keep current move centered without a font-loading event');
    await page.evaluate(()=>{document.querySelector('#strip').style.removeProperty('--move-font');document.querySelector('#strip').style.removeProperty('letter-spacing');document.fonts.dispatchEvent(new Event('loadingdone'));});
    await page.evaluate(()=>{window.view={...window.view,current:window.view.main.at(-1).cursor};window.strip.update(window.view);});assert.ok(await centerError()<3,'endpoint centers before incremental refresh');
    const endpointRange=await vp.evaluate(node=>({left:node.scrollLeft,max:node.scrollWidth-node.clientWidth}));assert.ok(endpointRange.left<=endpointRange.max);
    await page.evaluate(()=>window.strip.update({...window.view}));assert.equal(await vp.evaluate(node=>node.scrollLeft),endpointRange.left,'clamp never lowers a valid native endpoint offset');assert.ok(await centerError()<3,'same-cursor refresh preserves endpoint centering including viewport padding');
    await vp.evaluate(node=>{node.style.border='3px solid transparent';node.style.height='80px';node.style.overflowY='scroll';node.style.scrollbarWidth='auto';});await page.evaluate(()=>window.strip.relayout());await page.waitForTimeout(40);
    const scrollbarRange=await vp.evaluate(node=>({left:node.scrollLeft,max:node.scrollWidth-node.clientWidth,nonClient:node.offsetWidth-node.clientWidth}));assert.ok(scrollbarRange.nonClient>=6,'border/scrollbar case has a nonzero outer-client difference');assert.ok(await centerError()<1.5,'endpoint centers with border and vertical scrollbar');
    await page.evaluate(()=>window.strip.update({...window.view}));assert.equal(await vp.evaluate(node=>node.scrollLeft),scrollbarRange.left,'scrollbar clamp retains a valid offset');assert.ok(await centerError()<1.5);
    await vp.evaluate(node=>{for(const name of ['border','height','overflow-y','scrollbar-width'])node.style.removeProperty(name);});await page.evaluate(()=>window.strip.relayout());

    await page.evaluate(()=>{document.querySelector('#strip').style.width='320px';window.view={...window.view,current:{kind:'main',ply:0}};window.strip.update(window.view);});await page.waitForTimeout(80);
    const incremental=await page.evaluate(()=>{const shadow=document.querySelector('#strip').firstElementChild.shadowRoot,button=shadow.querySelector('button[data-cursor="m:2"]'),label=button.querySelector('.san'),viewport=shadow.querySelector('.viewport');button.focus({preventScroll:true});viewport.dispatchEvent(new PointerEvent('pointerdown',{pointerId:19,button:0,pointerType:'touch',bubbles:true}));const before=viewport.scrollLeft;window.strip.updateMove({kind:'main',ply:2},{classification:'quality-best',iconId:'quality',iconLabel:'Best move'});const result={sameButton:shadow.querySelector('button[data-cursor="m:2"]')===button,sameLabel:button.querySelector('.san')===label,focused:shadow.activeElement===button,scroll:viewport.scrollLeft===before,icon:!!button.querySelector('.icon'),pointer:window.strip.getInteractionState().pointerActive,bounds:window.strip.getCurrentBounds()?.key};window.dispatchEvent(new PointerEvent('pointerup',{pointerId:19}));return result;});assert.deepEqual(incremental,{sameButton:true,sameLabel:true,focused:true,scroll:true,icon:true,pointer:true,bounds:'m:0'});
    const copied=await page.evaluate(()=>{const shadow=document.querySelector('#strip').firstElementChild.shadowRoot,button=shadow.querySelector('button[data-cursor="m:2"]'),range=document.createRange(),selection=window.getSelection(),data=new DataTransfer();range.selectNodeContents(button.querySelector('.san'));selection.removeAllRanges();selection.addRange(range);button.dispatchEvent(new ClipboardEvent('copy',{clipboardData:data,bubbles:true,composed:true,cancelable:true}));selection.removeAllRanges();return data.getData('text/plain');});assert.equal(copied,'1...Nf2');
    await page.waitForTimeout(220);
    await vp.evaluate(node=>{node.scrollLeft=500;});await page.waitForTimeout(40);assert.ok((await page.evaluate(()=>window.events)).some(x=>x.source==='scroll'),'native scrolling without a pointer/wheel prelude selects as in the original');
    await page.evaluate(()=>{window.events=[];window.strip.center();});await page.waitForTimeout(40);assert.equal((await page.evaluate(()=>window.events)).filter(x=>x.source==='scroll').length,0,'component programmatic centering must not select');
    await page.evaluate(()=>window.strip.center());await vp.dispatchEvent('pointerdown',{pointerId:11,button:0,pointerType:'touch'});
    await vp.evaluate(node=>{node.scrollLeft=250;});await page.waitForTimeout(50);
    const during=await page.evaluate(()=>({events:window.events,interaction:window.strip.getInteractionState(),current:window.view.current}));assert.ok(during.events.some(x=>x.source==='scroll'),'center crossing selects before pointer release');assert.equal(during.interaction.pointerActive,true);assert.equal(during.interaction.userGesture,true);
    const heldExtent=await vp.evaluate(node=>node.scrollWidth);const previousLine=await page.evaluate(()=>window.view.selectedLine);
    await page.evaluate(()=>{window.view={...window.view,selectedLine:[...window.view.main.slice(0,4).map(x=>x.cursor),...window.view.branches[0].moves.map(x=>x.cursor)]};window.strip.update(window.view);});
    assert.equal(await vp.evaluate(node=>node.scrollWidth),heldExtent,'selected-line feedback cannot shrink native clipping extent during held scrolling');
    await page.evaluate(line=>{window.view={...window.view,selectedLine:line};window.strip.update(window.view);},previousLine);
    const heldBefore=await vp.evaluate(node=>node.scrollLeft);await vp.evaluate(node=>node.ownerDocument.fonts.dispatchEvent(new Event('loadingdone')));assert.equal(await vp.evaluate(node=>node.scrollLeft),heldBefore,'late fonts cannot interrupt a held scroll gesture');
    const dest=during.current;await vp.evaluate(node=>{node.dispatchEvent(new Event('scroll'));node.dispatchEvent(new Event('scroll'));});await page.waitForTimeout(40);assert.equal((await page.evaluate(()=>window.events)).filter(x=>x.source==='scroll'&&JSON.stringify(x.cursor)===JSON.stringify(dest)).length,1,'one request per crossing');
    await vp.evaluate(node=>{node.scrollLeft=20;});await page.waitForTimeout(50);assert.ok((await page.evaluate(()=>window.events)).filter(x=>x.source==='scroll').length>=2,'reversal selects again');
    await page.evaluate(()=>window.dispatchEvent(new PointerEvent('pointerup',{pointerId:11})));await page.waitForTimeout(220);assert.equal((await page.evaluate(()=>window.strip.getInteractionState())).userGesture,false);
    await vp.dispatchEvent('pointerdown',{pointerId:22,button:0,pointerType:'touch'});await vp.evaluate(node=>{node.scrollLeft=150;});await page.waitForTimeout(50);await page.evaluate(()=>window.dispatchEvent(new PointerEvent('pointerup',{pointerId:22})));await page.waitForTimeout(220);
    assert.equal(await page.evaluate(()=>window.strip.getInteractionState().userPositioned),true,'manual scroll owns positioning');
    await vp.dispatchEvent('pointerdown',{pointerId:23,button:0,pointerType:'touch'});await page.evaluate(()=>window.dispatchEvent(new PointerEvent('pointerup',{pointerId:23})));assert.equal(await page.evaluate(()=>window.strip.getInteractionState().userPositioned),false,'a touch with no movement returns positioning ownership as in the original');await page.waitForTimeout(220);
    await page.evaluate(()=>{window.view={...window.view,current:{kind:'main',ply:9}};window.strip.update(window.view);});
    assert.equal(await page.evaluate(()=>window.strip.getInteractionState().userPositioned),false,'controlled navigation returns positioning ownership');
    const navigationWidth=await root.locator('button[data-cursor="m:9"]').evaluate(button=>button.getBoundingClientRect().width);
    await page.evaluate(()=>{document.querySelector('#strip').style.setProperty('--move-font','monospace');document.querySelector('#strip').style.letterSpacing='5px';document.fonts.dispatchEvent(new Event('loadingdone'));});await page.waitForTimeout(40);
    assert.ok(Math.abs(await root.locator('button[data-cursor="m:9"]').evaluate(button=>button.getBoundingClientRect().width)-navigationWidth)>3);
    assert.ok(await centerError()<3,'font change recenters after manual scroll then controlled navigation');
    await page.evaluate(()=>{document.querySelector('#strip').style.removeProperty('--move-font');document.querySelector('#strip').style.removeProperty('letter-spacing');document.fonts.dispatchEvent(new Event('loadingdone'));});
    await page.waitForTimeout(80);
    await page.evaluate(()=>{window.events=[];window.view={...window.view,selectedLine:[...window.view.main.slice(0,4).map(x=>x.cursor),...window.view.branches[0].moves.map(x=>x.cursor)],current:{kind:'branch',branchId:'short',index:2}};window.strip.update(window.view);});
    const branchMetrics=await vp.evaluate(node=>({left:node.scrollLeft,max:node.scrollWidth-node.clientWidth}));assert.ok(Math.abs(branchMetrics.left-branchMetrics.max)<3,`branch endpoint centerable: ${JSON.stringify({branchMetrics,firstMetrics})}`);assert.ok(branchMetrics.max<firstMetrics.max,'longer main/sibling cannot extend native range');
    // KE-NAV-004: a short branch stays natively bounded during touch, not only after settle.
    await page.waitForTimeout(260);
    const touchBox=await vp.boundingBox(),cdp=await page.context().newCDPSession(page);
    const point={x:touchBox.x+touchBox.width*.8,y:touchBox.y+touchBox.height-8,id:7,radiusX:2,radiusY:2,force:1};
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[point]});
    assert.equal(await vp.evaluate(node=>node.scrollWidth-node.clientWidth),branchMetrics.max,'touch start cannot reopen the full tree beyond a short branch endpoint');
    for(let step=1;step<=8;step++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{...point,x:point.x-step*22}]});await page.waitForTimeout(35);assert.ok(await vp.evaluate(node=>node.scrollLeft)<=branchMetrics.max,'native touch cannot overscroll a short branch');}
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await cdp.detach();await page.waitForTimeout(300);
    assert.ok(await centerError()<3,'branch endpoint remains centered after native overscroll attempt');
    assert.ok(Number.isFinite((await page.evaluate(()=>window.strip.getBranchRows())).short));
    const painted=await root.locator('button[data-cursor="b:long:0"]').evaluate(button=>{const r=button.getBoundingClientRect(),shadow=button.getRootNode(),viewport=shadow.querySelector('.viewport').getBoundingClientRect(),x=Math.max(viewport.left+2,Math.min(viewport.right-2,r.left+r.width/2)),y=r.top+r.height/2;return r.left<viewport.right&&r.right>viewport.left&&shadow.elementFromPoint(x,y)?.closest('button')===button;});assert.equal(painted,true,'long sibling remains painted inside bounded viewport');
    const aligned=await root.evaluate(node=>{const shadow=node.shadowRoot,anchor=shadow.querySelector('button[data-cursor="b:short:1"]').getBoundingClientRect(),child=shadow.querySelector('button[data-cursor="b:child:0"]').getBoundingClientRect();const a=shadow.querySelector('button[data-cursor=\"b:short:1\"]'),c=shadow.querySelector('button[data-cursor=\"b:child:0\"]');return Math.abs(anchor.left+parseFloat(getComputedStyle(a).paddingLeft)-child.left-parseFloat(getComputedStyle(c).paddingLeft));});assert.ok(aligned<3,'nested child text starts under its canonical anchor text');
    await root.locator('button[data-cursor="b:short:1"]').click();assert.deepEqual((await page.evaluate(()=>window.events)).filter(x=>x.source==='click').at(-1)?.cursor,{kind:'branch',branchId:'short',index:1},JSON.stringify(await page.evaluate(()=>window.events)));
    await root.locator('button[data-cursor="m:1"]').focus();await page.keyboard.press('ArrowRight');assert.equal(await root.locator('button:focus').getAttribute('data-cursor'),'m:2');await page.keyboard.press('Enter');assert.equal((await page.evaluate(()=>window.events)).at(-1).source,'keyboard');await page.keyboard.press('a');assert.equal((await page.evaluate(()=>window.events)).at(-1).command,'a');
    await page.evaluate(()=>{window.strip.setGestureBlocked(true);window.view={...window.view,current:{kind:'main',ply:9}};window.strip.update(window.view);});assert.equal(await root.locator('button.current').getAttribute('data-cursor'),'m:9');await page.evaluate(()=>window.strip.setGestureBlocked(false));assert.equal(await root.locator('button.current').getAttribute('data-cursor'),'m:9');
    assert.deepEqual(errors,[]);await page.evaluate(()=>window.strip.dispose());assert.equal(await page.locator('#strip').innerHTML(),'');
    await page.evaluate(async initial=>{const {mountMoveStrip}=await import('/move-strip.js');const custom=document.createElement('div'),disabled=document.createElement('div');custom.id='custom';disabled.id='disabled';document.body.append(custom,disabled);window.customCommands=[];window.disabledCommands=[];window.customStrip=mountMoveStrip(custom,{view:initial,onNavigate(){},onCommand(id){window.customCommands.push(id);},keymap:{x:'export-fen',ArrowUp:'parent-line'},figurines:false});window.disabledStrip=mountMoveStrip(disabled,{view:initial,onNavigate(){},onCommand(id){window.disabledCommands.push(id);},keymap:{},figurines:{N:'♘'}});},view);
    assert.equal(await page.locator('#custom > div .san').nth(1).textContent(),'Nf1','figurines:false keeps literal SAN');
    assert.equal(await page.locator('#disabled > div .san').nth(1).textContent(),'♘f1','a custom figurine map replaces listed letters');
    await page.locator('#custom > div button[data-cursor="m:1"]').focus();await page.keyboard.press('x');await page.keyboard.press('ArrowUp');await page.keyboard.press('a');assert.deepEqual(await page.evaluate(()=>window.customCommands),['export-fen','parent-line']);
    await page.locator('#disabled > div button[data-cursor="m:1"]').focus();await page.keyboard.press('b');assert.deepEqual(await page.evaluate(()=>window.disabledCommands),[],'empty keymap disables app commands');
    await page.evaluate(async initial=>{
      const {mountMoveStrip}=await import('/move-strip.js');const host=document.createElement('div');host.id='plain';host.style.cssText='width:320px;--ink:#111111';document.body.append(host);
      window.plainStrip=mountMoveStrip(host,{view:initial,classifications:false,onNavigate(){},appearance:{resolveIcon(){throw Error('Plain mode must not resolve classification icons')}}});
    },view);
    const plain=page.locator('#plain button[data-cursor="m:1"]'),classified=page.locator('#custom button[data-cursor="m:1"]');
    assert.equal(await page.locator('#plain .icon-slot').count(),0);
    const plainWidth=(await plain.boundingBox()).width;
    assert.ok((await classified.boundingBox()).width>=plainWidth+14,'default mode reserves icon width');
    await plain.focus();
    await page.evaluate(()=>window.plainStrip.updateMove({kind:'main',ply:1},{classification:'best',iconId:'quality',iconLabel:'Best move',color:'#ff0000',comment:'Move comment'}));
    assert.equal((await plain.boundingBox()).width,plainWidth,'late assessment cannot add spacing in plain mode');
    assert.equal(await plain.getAttribute('data-classification'),null);
    assert.equal(await plain.getAttribute('aria-label'),'1 . Nf1');
    assert.equal(await plain.getAttribute('title'),'Move comment');
    assert.equal(await plain.evaluate(b=>getComputedStyle(b).color),'rgb(17, 17, 17)');
    assert.equal(await plain.evaluate(b=>b===b.getRootNode().activeElement),true,'late patch preserves focus');
    await page.locator('#plain').evaluate(h=>h.style.setProperty('--ink','#ffffff'));
    assert.equal(await plain.evaluate(b=>getComputedStyle(b).color),'rgb(255, 255, 255)');
    await page.locator('#plain').evaluate(h=>h.style.setProperty('--move-strip-text','#123456'));
    assert.equal(await plain.evaluate(b=>getComputedStyle(b).color),'rgb(18, 52, 86)');
    await page.evaluate(()=>{window.plainStrip.dispose();window.customStrip.dispose();window.disabledStrip.dispose();});await page.close();
  }}finally{await browser.close();server.close();}
});

test('metric changes coalesce outside observer delivery and pending rendering is canceled on disposal',async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  try {
    const page=await browser.newPage();await page.goto(`http://127.0.0.1:${server.address().port}`);
    const result=await page.evaluate(async initial=>{
      await document.fonts.ready;
      const observers=[];window.ResizeObserver=class {constructor(callback){this.callback=callback;observers.push(this);}observe(){}disconnect(){}};
      const {mountMoveStrip}=await import('/move-strip.js');
      const strip=mountMoveStrip(document.querySelector('#strip'),{view:initial,onNavigate(){}});
      await Promise.resolve(); // complete the initial font-ready relayout
      let layouts=0;strip.subscribe(()=>layouts++);
      const frames=new Map();let serial=0,canceled=0;
      window.requestAnimationFrame=callback=>{frames.set(++serial,callback);return serial;};
      window.cancelAnimationFrame=id=>{if(frames.delete(id))canceled++;};
      let button=document.querySelector('#strip').firstElementChild.shadowRoot.querySelector('button');
      const metric=observers[0];
      button.style.paddingLeft='30px';metric.callback([{target:button}]);
      button.style.paddingLeft='40px';metric.callback([{target:button}]);
      const deferred={frames:frames.size,layouts};
      const scheduled=[...frames.values()];frames.clear();scheduled.forEach(callback=>callback(performance.now()));
      const completed={frames:frames.size,layouts};
      button=document.querySelector('#strip').firstElementChild.shadowRoot.querySelector('button');
      metric.callback([{target:button}]);const unchanged=frames.size;
      button.style.paddingLeft='50px';metric.callback([{target:button}]);
      const stale=[...frames.values()];strip.dispose();stale.forEach(callback=>callback(performance.now()));
      return {deferred,completed,unchanged,canceled,remaining:frames.size,layouts,children:document.querySelector('#strip').childElementCount};
    },view);
    assert.deepEqual(result,{deferred:{frames:1,layouts:0},completed:{frames:0,layouts:1},unchanged:0,canceled:1,remaining:0,layouts:1,children:0});
  } finally {await browser.close();server.close();}
});
