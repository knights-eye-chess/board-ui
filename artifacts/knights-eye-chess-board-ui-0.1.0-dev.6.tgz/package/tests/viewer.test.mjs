import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { chromium } from 'playwright';

test('composite coordinates gestures, owns scoped transport and panel, and cleans up',async()=>{
 const server=createServer((req,res)=>{try{if(req.url==='/'){res.setHeader('content-type','text/html');res.end('<div id="host" style="width:320px"><div><div id="board"></div><div id="controls" style="display:grid;grid-template-columns:32px 1fr 32px"><button id="prev">Back</button><div id="strip"></div><button id="next">Next</button></div></div><input id="editor"></div><input id="outside">');}else{res.setHeader('content-type','text/javascript');res.end(readFileSync(new URL('../dist'+req.url,import.meta.url)));}}catch{res.statusCode=404;res.end();}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 try{const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto(`http://127.0.0.1:${server.address().port}`);
 await page.evaluate(async()=>{const{mountBoardViewer}=await import('/viewer.js');window.commands=[];window.viewer=mountBoardViewer(document.querySelector('#host'),{slots:{board:document.querySelector('#board'),moveStrip:document.querySelector('#strip'),previous:document.querySelector('#prev'),next:document.querySelector('#next')},moveStripPanel:{appHost:document.querySelector('#host'),controlsHost:document.querySelector('#controls')},board:{state:{position:{e1:'K',e8:'k'},orientation:'white',selectedSquare:null,permissions:{select:true,move:false},legalMoves:[]},pieceUrl:()=> 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg"/%3E',onSelect(){},onMove(){}},moveStrip:{view:{main:[{cursor:{kind:'main',ply:0},label:'Start'}],selectedLine:[{kind:'main',ply:0}],current:{kind:'main',ply:0}},onNavigate(){}},onNavigationCommand(c){window.commands.push(c);}});});
 assert.equal(await page.locator('[data-board-strip-expand]').isVisible(),false);assert.equal(await page.locator('#board .sq').count(),64);
 await page.locator('#next').click();assert.deepEqual(await page.evaluate(()=>window.commands),['next']);
 await page.locator('#next').focus();await page.keyboard.press('ArrowLeft');assert.equal((await page.evaluate(()=>window.commands)).at(-1),'previous');
 const before=(await page.evaluate(()=>window.commands)).length;await page.locator('#editor').focus();await page.keyboard.press('ArrowLeft');await page.locator('#outside').focus();await page.keyboard.press('ArrowRight');assert.equal((await page.evaluate(()=>window.commands)).length,before);
 const rect=await page.locator('#next').boundingBox();await page.mouse.move(rect.x+rect.width/2,rect.y+rect.height/2);await page.mouse.down();await page.waitForTimeout(460);await page.mouse.up();assert.ok((await page.evaluate(()=>window.commands)).length>=before+2);
 await page.evaluate(()=>window.viewer.updateBoardOverlays('reference',{highlights:[{square:'e4',tag:'reference',color:'#ff0000'}]}));assert.equal(await page.locator('#board [data-highlight-tag="reference"]').getAttribute('data-square'),'e4');await page.evaluate(()=>window.viewer.updateBoardOverlays('reference',null));assert.equal(await page.locator('#board [data-highlight-tag]').count(),0);
 await page.locator('#prev').focus();await page.evaluate(()=>window.viewer.updateNavigationControls({previousDisabled:true,nextDisabled:false}));await page.keyboard.press('Home');assert.equal((await page.evaluate(()=>window.commands)).at(-1),'start');assert.equal(await page.locator('#prev').isDisabled(),true);
 await page.evaluate(()=>{window.viewer.dispose();window.viewer.dispose();});assert.equal(await page.locator('[data-board-strip-panel]').count(),0);assert.equal(await page.locator('#board').innerHTML(),'');assert.equal(await page.locator('#strip').innerHTML(),'');assert.equal(await page.locator('#controls > #strip').count(),1);assert.deepEqual(errors,[]);
 }finally{await browser.close();server.close();}
});
